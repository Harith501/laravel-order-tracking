<!DOCTYPE html>
<html lang="en" class="h-100">
<head>
    <meta charset="UTF-8">
    <title><?php echo $__env->yieldContent('title', 'Daily Order Tracker'); ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="d-flex flex-column h-100">

    
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark mb-4">
        <div class="container">
            <a class="navbar-brand" href="<?php echo e(route('front')); ?>">SINOR TECHNOLOGY SDN BHD</a>

            <div class="d-flex">
                <a class="btn btn-outline-primary me-2" href="<?php echo e(route('orders.index')); ?>">Orders</a>
            </div>
        </div>
    </nav>

    
    <main class="flex-fill">
        <div class="container">
            <?php echo $__env->yieldContent('content'); ?>
        </div>
    </main>

    
    <footer class="bg-dark text-white text-center py-3 mt-auto">
        &copy; <?php echo e(date('Y')); ?> Sinor Technology Sdn Bhd. All rights reserved.
    </footer>

</body>
</html><?php /**PATH C:\xampp3\htdocs\Test\resources\views/layouts/app.blade.php ENDPATH**/ ?>