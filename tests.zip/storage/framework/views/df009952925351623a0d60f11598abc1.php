

<?php $__env->startSection('title', 'Order List'); ?>

<?php $__env->startSection('content'); ?>
    <h2 class="mb-4">Order List</h2>

    <?php if(session('success')): ?>
        <p class="alert alert-success"><?php echo e(session('success')); ?></p>
    <?php endif; ?>

    <div class="row mb-3 align-items-center">
        <!-- Create New Order button -->
        <div class="col-md-6">
            <a href="<?php echo e(route('orders.create')); ?>" class="btn btn-primary">Create New Order</a>
        </div>

        <!-- Search form -->
        <div class="col-md-6">
            <form action="<?php echo e(route('orders.index')); ?>" method="GET" class="d-flex justify-content-end">
                <input type="text" name="search" value="<?php echo e(request('search')); ?>" class="form-control me-2" placeholder="Search by">
                <button type="submit" class="btn btn-success">Search</button>
            </form>
        </div>
    </div>

    <table class="table table-bordered">
        <thead>
            <tr>
                <th>Order No</th>
                <th>Customer Name</th>
                <th>Installation Date</th>
                <th>Exchange</th>
                <th>Work Activity</th>
                <th>ID Slot Order</th>
                <th>Team Leader</th>
                <th>Team Member 1</th>
                <th>Team Member 2</th>
                <th>Team Member 3</th>
                <th>Status</th>
            </tr>
        </thead>
        <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td><?php echo e($order->order_no); ?></td>
                    <td><?php echo e($order->customer_name); ?></td>
                    <td><?php echo e($order->installation_date); ?></td>
                    <td><?php echo e($order->exchange); ?></td>
                    <td><?php echo e($order->work_activity); ?></td>
                    <td><?php echo e($order->id_slot_order); ?></td>
                    <td><?php echo e($order->team_leader); ?></td>
                    <td><?php echo e($order->team_member_1); ?></td>
                    <td><?php echo e($order->team_member_2); ?></td>
                    <td><?php echo e($order->team_member_3); ?></td>
                    <td><?php echo e($order->order_status); ?></td>
                    
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="12" class="text-center">No orders found.</td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp3\htdocs\Test\resources\views/orders/index.blade.php ENDPATH**/ ?>