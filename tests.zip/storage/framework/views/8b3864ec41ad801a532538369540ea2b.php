

<?php $__env->startSection('title', 'Sinor Technology Order Tracking'); ?>

<?php $__env->startSection('content'); ?>
    <div class="text-center py-5">
        <h1 class="mb-4">Welcome to Daily Order Tracker</h1>
        <p class="lead">Manage your team's daily installation orders efficiently.</p>

        <?php if(auth()->guard()->check()): ?>
            <?php if(Auth::user()->admin): ?>
                <a href="<?php echo e(route('orders.index')); ?>" class="btn btn-primary mt-3">Go to Orders</a>
            <?php endif; ?>
        <?php endif; ?>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp3\htdocs\Test\resources\views/orders/front.blade.php ENDPATH**/ ?>